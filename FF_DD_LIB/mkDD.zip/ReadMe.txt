  Tokenizing the FF DD by command line
  ====================================

  This readme introduces the way to build the environment to use tokenlizer of
  FF and how to tokenize the DD for FF device under WinXP/Windows7 console.

  We assume to install the FF tokenizer and FF standard library into the
  specific directory: c:\FF, No guarantee the tokenlizer can handle you DD
  smoothly, if you installed the FF tokenlizer into other directory.

  Make sure the operator must has the administrator permission under the Windows
  7 OS.


* Preparation for FF tokenlizer
  -----------------------------

  Before to install the DD tokenlizer for FF, The DD-IDE 1.20 and 3.70.zip from
  FF must be required.

  1. Run the setup.exe from DD-IDE 1.20 which includes the tokenlizer and
     DD-IDE. if select the default install path, the c:/FF directory will be
     created automatically.

  2. Copy the DDL folder from 3.70.zip to C:\FF directory manually. this will
     create a new subdirectory,c:\ff\ddl, under the c:\ff.

  3. Copy two batch files:build_standard_libs.bat and mkDD.bat into c:\FF
     directory.

  4. Run build_standard_libs.bat, and press the key following the prompt.  This
     is a long time procedure, because it will build the standard library for
     version 4 and version 5 automatically. The standard library files are
     generatored into c:/FF/Release which is created by this step. Runing this
     batch file is must required but only needs to runs once.


* To tokenlize your DD
  --------------------

  General, The user's DD source file(.ddl) will be written at a specific
  directory under c:/FF, for example: C:/FF/productXX/.

  To tokenized the user's DD, run the mkDD.bat under the c:/ff directory.

  The command-line parameters for mkDD.bat:

  mkDD.bat DD-File [-4]

  Command Syntax:

  DD-File: Specify the path and file name of main DDL for your product. 

  -4: Optional, It will generate the compatible DD binary files(.ffo/.sym)

  -?: Optional, Display the usage for mkDD.bat.

  The generated binary files are saved into a specific directory under
  c:/ff/release.

  If no -4, the default will generate EDDL binary files(.ff5/.sy5).

* History
  -------

  Created on <2012-06-27 15:55:45> and verified on the WinXp PC which no lience
  for DD-IDE.
